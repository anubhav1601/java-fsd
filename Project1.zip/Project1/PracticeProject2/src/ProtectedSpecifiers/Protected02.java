package ProtectedSpecifiers;

public class Protected02 extends Protected {
	public static void main(String[] args) {
		Protected s = new Protected();
		s.display();
	}

}
