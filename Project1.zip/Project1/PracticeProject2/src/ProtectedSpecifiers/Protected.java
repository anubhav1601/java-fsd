package ProtectedSpecifiers;

public class Protected {
	protected void display() {
		System.out.println("using priotected access specifiers");
		
	}

}
