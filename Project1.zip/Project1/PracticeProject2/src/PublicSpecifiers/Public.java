package PublicSpecifiers;
public class Public {

	public void display() {
		System.out.println("Using public access specifier ");
	}
	
}
