package PublicSpecifiers02;
import PublicSpecifiers.*;

public class Public02 {

	public static void main(String[] args) {
		Public s = new Public();
		s.display();
		
	}
}
