package DefaultSpecifiers;
public class AccessSpecifiers {
 
  void display() 
     { 
         System.out.println("You are currentlu using defalut access specifier"); 
     } 



	public static void main(String[] args) {
		//default
		System.out.println("Dafault Access Specifier");
		AccessSpecifiers obj = new AccessSpecifiers(); 		  
        obj.display(); 

	}
}

