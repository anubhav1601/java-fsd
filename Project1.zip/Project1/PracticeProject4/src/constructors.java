
class Student{
int id;
String name;
void display() {
System.out.println(id+" "+name);
}
}
class Stan{
int id;
String name;
Stan(int i,String n)
{
id=i;
name=n;
}
void display()
{
System.out.println(id+" "+name);
}
}
public class constructors {
public static void main(String args[])
{
Student stu=new Student();
Student stu1=new Student();
stu.display();
stu1.display();

Stan sta1=new Stan(1,"Hello");
Stan sta2=new Stan(2,"World");
sta1.display();
sta2.display();
}

}