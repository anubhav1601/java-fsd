
class callMethod {
	int val=100;

	int operation(int val) {
		val =val*10/100;
		return(val);
	}
 }

  class overloadMethod {
		public void area(int b,int h)
	    {
	         System.out.println("Triangle area  : "+(0.5*b*h));
	    }
	    public void area(int r) 
	    {
	         System.out.println("Circle area : "+(3.14*r*r));
	    }

  }



public class First {

public int multipynumbers(int a,int b) {
	int z=a*b;
	return z;
}

public static void main(String[] args) {

	First b=new First();
	int ans= b.multipynumbers(10,3);
	System.out.println("Multipilcation is :"+ans);
	
	callMethod d = new callMethod();
	System.out.println("Before operation "+d.val);
	d.operation(100);
	System.out.println("After operation "+d.val);
	
	overloadMethod ob=new overloadMethod();
    ob.area(11,10);
    ob.area(10);  
	}
}