public class LinearSearch {
   public static void main(String args[]){
      int array[] = {4,8,99,102,122};
      int size = array.length;
      int value = 122;
      int s=0;

      for (int i=0 ;i< size; i++){
         if(array[i]==value){
            System.out.println("Found at index :"+ i);
            s+=1;
         }
         
      }
      if(s==0) {
     	 System.out.println("Not found");
      }
   }
}
