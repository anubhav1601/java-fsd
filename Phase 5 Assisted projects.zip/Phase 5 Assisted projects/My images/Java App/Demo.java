public class Demo {
    public static void main(String args[]){
        System.out.println("Welcome to Simple Java Program using Docker");
    }
}