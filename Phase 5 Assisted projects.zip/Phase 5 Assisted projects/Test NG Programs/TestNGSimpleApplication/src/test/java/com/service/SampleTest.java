package com.service;

import org.testng.annotations.Test;

public class SampleTest {
	@Test
	  public void f1() {
		  System.out.println("While testing first method-second class");
	  }
	  
	  @Test
	  public void f2() {
		  System.out.println("While testing second method-second class");
	  }
}
