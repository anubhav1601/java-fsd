package MulTwoMatrices;

public class test {
	public static void main(String[] args) {
		int row1 = 2, col1 = 2;
		int row2 = 2, col2 = 3;
		int[][] firstMatrix = { { 4, -3, }, { 2, 7 } };
		int[][] secondMatrix = { { 9, 5, 2 }, { 4, 6, 1 } };
		int[][] result = multiplyMatrices(firstMatrix, secondMatrix, row1, col1, col2);
		displayProduct(result);
	}

	public static int[][] multiplyMatrices(int[][] firstMatrix, int[][] secondMatrix, int row1, int col1, int col2) {
		int[][] result = new int[row1][col2];
		for (int i = 0; i < row1; i++) {
			for (int j = 0; j < col2; j++) {
				for (int k = 0; k < col1; k++) {
					result[i][j] += firstMatrix[i][k] * secondMatrix[k][j];
				}
			}
		}
		return result;
	}

	public static void displayProduct(int[][] product) {
		System.out.println("The product of two given matrices are: ");
		for (int[] row : product) {
			for (int column : row) {
				System.out.print(column + "    ");
			}
			System.out.println();
		}
	}
}
