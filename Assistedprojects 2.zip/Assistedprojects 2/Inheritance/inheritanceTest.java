package Inheritance;

public class inheritanceTest {

public static void main(String[] args) {
inheritance1 obj = new inheritance1();

obj.getValues();
obj.showValues();
obj.sum();
}
}