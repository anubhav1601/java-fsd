package Inheritance;
	import java.util.Scanner;

	public class inheritance {
	 int x,y;
	     void getValues() {
	Scanner sc = new Scanner(System.in);
	System.out.println("enter two values....");
	this.x = sc.nextInt();
	this.y = sc.nextInt();


	}
	void showValues() {
	System.out.println("x:"+this.x+" y:"+this.y);
	}

	}




