package Abstraction;


	public class pnb extends Bank {

		double y=7.5;
		@Override
		void RateOfInterest() {
		// TODO Auto-generated method stub
		System.out.println("Rate of interest in PNB is: "+y);
		}

		}



