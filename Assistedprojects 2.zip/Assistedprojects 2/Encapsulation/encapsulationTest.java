package Encapsulation;

public class encapsulationTest {
	public static void main(String[] args) {
		encapsulation obj = new encapsulation();
		obj.setName("HEy there");
		System.out.println(obj.getName());
		}
		}


